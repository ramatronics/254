/**
* @file: rt_Task_ext.h
*/
extern int rt_tsk_count_get (void);
/* end of file */